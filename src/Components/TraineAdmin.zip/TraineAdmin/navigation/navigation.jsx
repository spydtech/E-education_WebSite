import React, { useState } from "react";
// import ProfileSection from "./ProfileSection";
import ProfileSection from "../profilesection/ProfileSection";
// import ForgotPassword from "./ForgotPassword";
import TraineForgotPassword from "../ForgotPassword/forgotpassword";
// import UpdatePassword from "./UpdatePassword";
import TraineeUpdatePassword from "../UpdatePassword/updatepassword";

const TraineeNavigation = () => {
  const sections = ["Profile", "Forgot Password", "Update Password"];
  const [currentSection, setCurrentSection] = useState(0);

  const handleSectionChange = (index) => {
    setCurrentSection(index);
  };

  return (
    <>
      <nav className="bg-blue-600 p-4 shadow-lg">
        <div className="container mx-auto flex items-center justify-center">
          <div className="flex space-x-4">
            {sections.map((section, index) => (
              <button
                key={index}
                className={`text-white hover:text-gray-200 ${
                  currentSection === index ? "text-gray-200" : ""
                }`}
                onClick={() => handleSectionChange(index)}
              >
                {section}
              </button>
            ))}
          </div>
        </div>
      </nav>
      <div className="container mx-auto p-4">
        {currentSection === 0 && <ProfileSection />}
        {currentSection === 1 && <TraineForgotPassword />}
        {currentSection === 2 && <TraineeUpdatePassword />}
      </div>
    </>
  );
};

export default TraineeNavigation;
