// import React from "react";
// import { MdImportantDevices } from "react-icons/md";
// import { FaGreaterThan } from "react-icons/fa6";
// import { IoWoman } from "react-icons/io5";
// import { AuditOutlined } from "@ant-design/icons";
// import { Link } from "react-router-dom";

// function Certified() {
//   return (
//     <div className="flex flex-col lg:flex-row justify-center items-center min-h-screen bg-gray-100 px-4 py-8">
//       <div className="bg-white mb-8 lg:mb-0 lg:mr-8 w-full max-w-xs md:max-w-sm lg:max-w-md h-[250px] shadow-lg rounded-lg p-6 transform transition-transform hover:scale-105 balloon-hover group">
//         <div className="flex items-start justify-start mb-4">
//           <MdImportantDevices className="h-[60px] w-[60px] text-[#0098F1] rounded-full p-2 transition-colors" />
//         </div>
//         <h1 className="text-[#0098F1] text-lg md:text-xl font-semibold mb-2 group-hover:text-white">
//           Get Started Learning Quickly with E-education
//         </h1>
//         <p className="flex items-center text-[#0098F1] text-md md:text-lg font-medium group-hover:text-white">
//           <span>Enroll Now</span>
//           <FaGreaterThan className="ml-2" />
//         </p>
//       </div>

//       <div className="bg-white mb-8 lg:mb-0 lg:mr-8 w-full max-w-xs md:max-w-sm lg:max-w-md h-[250px] shadow-lg rounded-lg p-6 transform transition-transform hover:scale-105 balloon-hover group">
//         <div className="flex items-start justify-start mb-4">
//           <IoWoman className="h-[60px] w-[60px] text-[#0098F1] rounded-full p-2 transition-colors" />
//         </div>
//         <h1 className="text-[#0098F1] text-lg md:text-xl font-semibold mb-2 group-hover:text-white">
//           Get Started Learning Quickly with E-education
//         </h1>
//         <p className="flex items-center text-[#0098F1] text-md md:text-lg font-medium group-hover:text-white">
//           <span>Enroll Now</span>
//           <FaGreaterThan className="ml-2" />
//         </p>
//       </div>

//       <div className="bg-white mb-8 lg:mb-0 w-full max-w-xs md:max-w-sm lg:max-w-md h-[250px] shadow-lg rounded-lg p-6 transform transition-transform hover:scale-105 balloon-hover group">
//         <div className="flex items-start justify-start mb-4">
//           <AuditOutlined className="h-[60px] w-[60px] pl-5 text-[#0098F1] rounded-full p-2 transition-colors" />
//         </div>
//         <h1 className="text-[#0098F1] text-lg md:text-xl font-semibold mb-2 group-hover:text-white">
//           Get Started Learning Quickly with E-education
//         </h1>
//         <p className="flex items-center text-[#0098F1] text-md md:text-lg font-medium group-hover:text-white">
//           <span>Enroll Now</span>
//           <FaGreaterThan className="ml-2" />
//         </p>
//       </div>
//     </div>
//   );
// }

// export default Certified;

import React from "react";
import { MdImportantDevices } from "react-icons/md";
import { FaGreaterThan } from "react-icons/fa6";
import { IoWoman } from "react-icons/io5";
import { AuditOutlined } from "@ant-design/icons";
import { Link } from "react-router-dom";

function Certified() {
  return (
    <div className="flex flex-col lg:flex-row justify-center items-center min-h-screen bg-gray-50 px-4 py-8">
      {/* Card 1 */}
      <div className="bg-blue-600 mb-8 lg:mb-0 lg:mr-8 w-full max-w-xs md:max-w-sm lg:max-w-md h-[250px] shadow-lg rounded-lg p-6 transform transition-transform hover:scale-105 hover:bg-blue-700 group">
        <div className="flex items-start justify-start mb-4">
          <MdImportantDevices className="h-[60px] w-[60px] bg-white text-blue-600 group-hover:text-white group-hover:bg-blue-500 rounded-full p-2 transition-colors" />
        </div>
        <h1 className="text-white group-hover:text-blue-100 text-lg md:text-xl font-semibold mb-2">
          Get Started Learning Quickly with E-education
        </h1>
        <p className="flex items-center text-white group-hover:text-blue-100 text-md md:text-lg font-medium">
          <Link to="/features">
            <span>Enroll Now</span>
          </Link>
          <FaGreaterThan className="ml-2 text-white group-hover:text-blue-100" />
        </p>
      </div>

      {/* Card 2 */}
      <div className="bg-white mb-8 lg:mb-0 lg:mr-8 w-full max-w-xs md:max-w-sm lg:max-w-md h-[250px] shadow-lg rounded-lg p-6 transform transition-transform hover:scale-105 hover:bg-blue-600 group">
        <div className="flex items-start justify-start mb-4">
          <IoWoman className="h-[60px] w-[60px] text-blue-600 group-hover:text-white bg-blue-100 group-hover:bg-blue-600 rounded-full p-2 transition-colors" />
        </div>
        <h1 className="text-blue-600 group-hover:text-white text-lg md:text-xl font-semibold mb-2">
          Get Started Learning Quickly with E-education
        </h1>
        <p className="flex items-center text-blue-600 group-hover:text-white text-md md:text-lg font-medium">
          <Link to="/features">
            <span>Enroll Now</span>
          </Link>
          <FaGreaterThan className="ml-2 text-blue-600 group-hover:text-white" />
        </p>
      </div>

      {/* Card 3 */}
      <div className="bg-white mb-8 lg:mb-0 w-full max-w-xs md:max-w-sm lg:max-w-md h-[250px] shadow-lg rounded-lg p-6 transform transition-transform hover:scale-105 hover:bg-blue-600 group">
        <div className="flex items-start justify-start mb-4">
          <AuditOutlined className="h-[60px] pl-6 w-[60px] text-blue-600 group-hover:text-white bg-blue-100 group-hover:bg-blue-600 rounded-full p-2 transition-colors" />
        </div>
        <h1 className="text-blue-600 group-hover:text-white text-lg md:text-xl font-semibold mb-2">
          Get Started Learning Quickly with E-education
        </h1>
        <p className="flex items-center text-blue-600 group-hover:text-white text-md md:text-lg font-medium">
          <Link to="/features">
            <span>Enroll Now</span>
          </Link>
          <FaGreaterThan className="ml-2 justify-center items-center  text-blue-600 group-hover:text-white" />
        </p>
      </div>
    </div>
  );
}

export default Certified;
