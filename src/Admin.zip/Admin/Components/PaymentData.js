import React from 'react'

const PaymentData = () => {
    return (
        <div>PaymentData</div>
    )
}

export default PaymentData